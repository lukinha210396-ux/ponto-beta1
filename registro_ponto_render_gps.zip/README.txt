Registro de Ponto - Deploy Render.com
====================================

1) Crie uma conta gratuita em https://render.com e faça login.
2) Clique em "New" → "Web Service".
3) Escolha "Deploy from ZIP" e faça upload deste arquivo ZIP.
4) Render irá instalar dependências, detectar Flask e iniciar o serviço.
5) Em poucos minutos você terá um link público do tipo:
   https://seu-projeto.onrender.com
6) Acesse pelo navegador. Login inicial:
   - Admin: usuario "admin", senha "admin"
7) Crie funcionários pelo painel do administrador.
8) Funcionários poderão registrar ponto de qualquer lugar.

Observação:
- Para atualizar o site, basta subir novamente o ZIP atualizado.
- Este projeto já inclui templates e CSS.
